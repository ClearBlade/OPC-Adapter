package dukdukgo

import (
	"net"
	"fmt"
	"bufio"
	duk "clearblade/go-duktape"
)

func sendConnectionRequest(ctx *duk.Context) int {
	connectionType := ctx.GetString(-3)
	connectionString := ctx.GetString(-2)
	ctx.PopN(2)

	fmt.Println("Connection type : ", connectionType)
	fmt.Println("String : ", connectionString)
	conn, _ := net.Dial(connectionType , connectionString)

	fmt.Println("Sending message ...")
	fmt.Fprintf(conn, "Write Error.Boolean")
	message, _ := bufio.NewReader(conn).ReadString('\n')
	fmt.Println("Got message : ", message)
	ctx.PushString(`{"response":"success"}`)
	ctx.JsonDecode(-1)
	return 1
}