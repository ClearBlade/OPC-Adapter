import SocketServer
import OpenOPC

gateway = "10.211.55.3"
opcHost = "10.211.55.3"
opcServer = 'Matrikon.OPC.Simulation'

class OCPHandler(SocketServer.BaseRequestHandler):
    def handle(self):
        # self.request is the TCP socket connected to the client
        self.data = self.request.recv(1024).strip()
        # print "{} wrote:".format(self.client_address[0])
        print self.data
        taglist = [self.data]

        print "Trying to connect to gateway ................ Fingers crossed!!"

        opcConnect = OpenOPC.open_client(gateway)
        opcConnect.connect(opcServer, opcHost)

        print "Phew Connected!!"

        tags = opcConnect.read(taglist)
        opcConnect.close()

        for i in range(len(tags)):
            (tag, reading, condition, time) = tags[i]
            print "%s    %s     %s     %s"%(tag, reading, condition, time)
            self.request.sendall(str(tags[i]))

if __name__ == "__main__":
    HOST, PORT = "localhost", 8999

    server = SocketServer.TCPServer((HOST, PORT), OCPHandler)
    server.serve_forever()