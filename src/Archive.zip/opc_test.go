package dukdukgo

import (
	"log"
	"strings"
	"testing"
	"clearblade/uuid"
)

var (
	ip_port = "127.0.0.1:8999"
	conn_type = "tcp"
)

func Test_sendConnectionRequest(t *testing.T) {
	code := `function test(req,resp){
		ClearBlade.init({"systemKey":"test_syskey","systemSecret":"test_syssec"});
		connect("127.0.0.1:8999","tcp",function(err,val){
			if (err){
				resp.error("error " + val);
			}else{
				resp.success(val)
			}
			});
}`
ee := NewExecutionEngine(test_syskey, test_syssec, "")
msg := ee.DoExecution(uuid.Uuid{}, code, "test", test_libs, nil)
log.Printf("%+v\n", msg)
if strings.Contains(msg["results"].(string), "error") {
	t.Error("recieved message " + msg["results"].(string))
}
}